# Discord Kayıt Botu
Discord Kayıt Botu Altyapısı v12
